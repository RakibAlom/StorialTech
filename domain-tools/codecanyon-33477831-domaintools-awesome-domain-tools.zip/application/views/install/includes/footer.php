        <div class="footer-text">
			Copyright © <?php echo(date("Y")); ?> <a href="<?php echo(VENDOR_URL); ?>" target="_blank"><?php echo(VENDOR_NAME); ?></a>, All rights reserved. 
		</div>
	</div>
</body>
</html>