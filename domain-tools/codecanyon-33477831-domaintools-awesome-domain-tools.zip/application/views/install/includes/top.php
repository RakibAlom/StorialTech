<div class="installer-logo-area">
    <a class="logo-icon" href="<?php echo(VENDOR_URL); ?>" target="_blank"><img width="235" src="<?php echo($base_url."application/views/install/assets/img/logo-dark.png"); ?>"></a>
</div>

<div class="text-center">
<div class="welcome-logo-text">
    <span><?php echo(PRODUCT_NAME); ?></span> Install Wizard
</div>

</div>
