<?php $this->theme->view('includes/header'); ?>

<?php $this->load->view('core/header_ad_spot'); ?>

<div class="mainPadding homepageFaqsAreaMain">
    <div class="homepageFaqsArea">
        <h1>404</h1>
        
        <p>The page you're looking for was not found.</p>
    </div>
</div>

<?php $this->theme->view('includes/footer'); ?>